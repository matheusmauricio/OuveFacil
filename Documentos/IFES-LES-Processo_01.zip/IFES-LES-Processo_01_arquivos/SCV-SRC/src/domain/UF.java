package domain;

public class UF {

    private String sigla;

    private String nome;

    private Cidade[] cidade;

    public UF() {
    }

    /**
     * @return the sigla
     */
    public String getSigla() {
        return sigla;
    }

    /**
     * @param sigla the sigla to set
     */
    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the cidade
     */
    public Cidade[] getCidade() {
        return cidade;
    }

    /**
     * @param cidade the cidade to set
     */
    public void setCidade(Cidade[] cidade) {
        this.cidade = cidade;
    }
    
    @Override
    public String toString(){
        return this.getSigla();
    }

}
