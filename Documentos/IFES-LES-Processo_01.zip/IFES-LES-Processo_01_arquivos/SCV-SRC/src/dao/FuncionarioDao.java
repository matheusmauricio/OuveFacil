package dao;

public class FuncionarioDao {
 
}
 
